import random


def play_game():
    # Generate a random number between 1 and 10
    secret_number = random.randint(1, 10)

    print("I'm thinking of a number between 1 and 10. You have 5 chances!")

    attempts = 5

    for i in range(attempts):
        guess = int(input(f"Attempt {i + 1}: Enter your guess: "))

        if guess == secret_number:
            print("🎉 Correct! You guessed the number.")
            return
        elif guess < secret_number:
            print("Too low!")
        else:
            print("Too high!")

        if i == attempts - 1:
            print(f"😢 Sorry, you're out of attempts. The number was {secret_number}.")


# Main loop
while True:
    play_game()
    play_again = input("Do you want to play again? (1=yes/2=no): ").strip().lower()
    if play_again != 1:
        print("Thanks for playing! Goodbye 👋")
        break