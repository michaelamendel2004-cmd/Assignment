# TASK 1
def task1(s):
    return s.lower()

print(task1("Hello"))
print(task1("here"))
print(task1("LOVELY"))


# TASK 2
def task2(s):
    return s.swapcase()

print(task2("My TheoPhaNy"))


# TASK 3
def task3(s):
    return "".join(ch for ch in s if not ch.isupper())

print(task3("TheoPhany"))


# TASK 4
def task4(s):
    upper = sum(1 for ch in s if ch.isupper())
    lower = sum(1 for ch in s if ch.islower())
    return f"Uppercase: {upper}, Lowercase: {lower}"

print(task4("THEOphany"))


# TASK 5
def task5(s):
    return "".join(ch for ch in s if ch.isalpha())

print(task5("Theo2023phany"))


# TASK 6
import math

def task6(a, b, c):
    s = (a + b + c) / 2
    area = math.sqrt(s * (s - a) * (s - b) * (s - c))
    return area

print(task6(3, 4, 5))


# TASK 7
def task7(names):
    print("Name".center(20, "-"))
    for name in names:
        print(name.ljust(20))

task7(["Joseph", "Theophany", "Mendelow", "Oheneba"])


# TASK 8
import string

def task8(s):
    s = s.strip()  # remove leading/trailing spaces
    s = "".join(ch for ch in s if ch not in string.punctuation)  # remove punctuation
    s = s.replace(" ", "")  # remove spaces
    return s

print(task8("   Theo, Phany!    "))