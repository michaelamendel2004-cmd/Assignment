#TASK 1
my_integer = 25
my_float = 19.75
my_string = "THE MINUTE YOU WAKE UP DEAD"
my_boolean = False

print(my_integer, type(my_integer))
print(my_float, type(my_float))
print(my_string, type(my_string))
print(my_boolean, type(my_boolean))




#TASK 2
print("TASK 2")

# a. Convert float to int
float_num = 19.99
int_num = int(float_num)
print(int_num, type(int_num))

# b. Convert int to string
int_value = 50
str_value = str(int_value)
print(str_value, type(str_value))

# c. Convert string to float
str_num = "50"
float_value = float(str_num)
print(float_value, type(float_value))



# TASK 3
print("TASK 3")

first_name = "Michael Mendelow" # input("Enter your first name: ")
last_name = "Acheampong" # input ("Enter your last name: ")
print("Hello,", first_name, last_name + "!")




print("TASK 4")

# a. Fixing the error
age = 21
print("You are " + str(age) + " years old.")

# b. Explanation:
# The error happens because you can't concatenate a string and an integer directly.
# The integer must be converted to a string before concatenation.



# TASK 5
print("TASK 5")

word = "py"  # input("Enter your favourite word:")
numOfTimes = 3 # int(input("How many times to repeat it?"))
print((word +" ")* numOfTimes)




