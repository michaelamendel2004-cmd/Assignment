def multiplication_table(n):
    print(f'multiplication table for {n}')
    for i in range(1,11):
        print(f'{n}*{i}={n*i}')
num=int(input('enter a num:'))
multiplication_table(num)